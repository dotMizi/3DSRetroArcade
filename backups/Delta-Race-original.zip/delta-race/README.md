# Delta Race — Nintendo 3DS Homebrew

Eigenständiger, von Omega Race inspirierter Vektor-Arenashooter. Eigener Code und eigene Grafik, keine übernommenen Arcade-Assets. Für Old/New Nintendo 3DS und 2DS mit eingerichtetem Homebrew Launcher.

## Sofort starten

1. SD-Karte am Mac öffnen.
2. Ordner `3ds/delta-race` auf der SD-Karte anlegen.
3. `delta-race.3dsx` und `delta-race.smdh` dorthin kopieren.
4. Karte sicher auswerfen, in den 3DS einsetzen und den Homebrew Launcher öffnen.
5. **Delta Race** auswählen, mit **A** oder **START** starten.

Der Homebrew Launcher muss bereits funktionieren. Das Projekt verändert oder installiert keine Systemsoftware. Eine `.3dsx` ist für den Homebrew Launcher bestimmt und keine installierbare CIA.

## Steuerung

| Eingabe | Aktion |
| --- | --- |
| Circle Pad links/rechts oder Steuerkreuz links/rechts | Raumschiff drehen |
| B, L, Steuerkreuz oben oder Circle Pad oben | Schub |
| A oder R halten | Dauerfeuer |
| X oder Steuerkreuz unten halten | Bremsen |
| START | Pause / weiterspielen; im Titelbild starten |
| A nach Game Over | Neue Runde |
| SELECT | Zum Homebrew Launcher zurückkehren |
| Touchscreen, unterer Bereich (ab y=140), linke Hälfte halten | Schub |
| Touchscreen, unterer Bereich, rechte Hälfte halten | Feuer |

Die Touch-Eingabe unterstützt jeweils eine Berührung. Mit physischen Tasten lassen sich Drehen, Schub und Feuer gleichzeitig bedienen.

## Spielregeln

Das Schiff gleitet mit Trägheit weiter. Wände und der zentrale Reaktor lassen Schiffe abprallen; Geschosse verschwinden beim Wandkontakt. Alle Gegner einer Welle zerstören, um die nächste Welle zu erreichen. Drei Leben pro Runde. Beim Start und nach einem Treffer schützt ein kurzzeitiger Schild (weißer Schiffsrumpf mit Ring).

- Orange Quadrate: Drohnen, 100 Punkte.
- Pinke Rauten: Verfolger, 200 Punkte.
- Orange Sechsecke: gepanzerte Gegner, zwei Treffer, 300 Punkte.
- Ab Welle 2 feuern Gegner pinke Geschosse auf das Schiff.
- Höhere Wellen erhöhen Gegnerzahl und Schwierigkeit; maximal 24 Gegner gleichzeitig.

Punkte, Bestwert, Leben und Welle stehen auf dem unteren Bildschirm. Der Bestwert wird bei Game Over oder beim Beenden unter `sdmc:/3ds/delta-race/highscore.txt` gespeichert. Falls die SD-Karte nicht beschreibbar ist, läuft das Spiel weiter; eine fehlgeschlagene Speicherung bei Game Over wird angezeigt. Das Spiel verwendet eine 2D-Vektoransicht und enthält keine Musik oder Soundeffekte.

## Auf dem Mac bauen

Vorhandene Installation: `/opt/devkitpro`, devkitARM r68-1 / GCC 16.1.0, libctru 2.7.0. Verwendet werden libctru und die standardmäßigen devkitPro-Werkzeuge; keine zusätzlichen Downloads nötig.

```sh
cd /Users/mziegler/delta-race
make -j4
```

Die Makefile setzt Standardpfade für diese Mac-Installation. Bei anderer Installation:

```sh
make DEVKITPRO=/anderer/pfad/devkitpro DEVKITARM=/anderer/pfad/devkitpro/devkitARM
```

Neu bauen: `make clean` und anschließend `make -j4`. Ergebnis: `delta-race.3dsx`, `delta-race.smdh` und die Debug-Datei `delta-race.elf`. Die Makefile basiert auf der installierten devkitPro-Anwendungsvorlage. Grafik und Eingaben verwenden die [libctru-APIs](https://github.com/devkitPro/libctru); der Ablauf orientiert sich an den [offiziellen 3DS-Beispielen](https://github.com/devkitPro/3ds-examples).

Optionaler Netzwerkstart, falls der Homebrew Launcher bereits Netloader aktiviert hat und im selben Netzwerk erreichbar ist:

```sh
/opt/devkitpro/tools/bin/3dslink delta-race.3dsx
```

## Prüfung

```sh
./tests/run.sh
```

Der Test kompiliert die plattformunabhängige Spiellogik mit dem Mac-C-Compiler und UndefinedBehaviorSanitizer. Er prüft Trägheit, Bremsen, Wände, Reaktor, Pause, Geschosse, Punkte, Wellenwechsel, Schutzschild, gegnerische Treffer und Game Over. Zusätzlich laufen 600.000 simulierte Frames mit 40 Startwerten und Zustandsprüfungen.

Die ARM-Version wurde ohne Compilerwarnungen gebaut. Der 3DSX-Header wurde geprüft; die Grafik wurde mit denselben Zeichenfunktionen als Vorschau gerendert und visuell kontrolliert. Auf diesem Mac wurde kein 3DS-Emulator gefunden. Ein tatsächlicher Start auf einem 3DS sowie Hardware-Eingaben, Bildrate und SD-Speicherung auf dem Gerät sind noch nicht verifiziert.

## Dateien

- `source/game.c`, `source/game.h`: Spiellogik, unabhängig von libctru.
- `source/main.c`: 3DS-Eingaben, Darstellung und SD-Bestwert.
- `tests/`: ausführbare Logiktests.
- `icon.png`: eigenes Delta-Symbol für den Homebrew Launcher.
- `LICENSE`: MIT-Lizenz für den Spielcode und das Symbol.
