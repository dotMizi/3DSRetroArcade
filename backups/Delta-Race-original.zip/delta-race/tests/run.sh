#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p build-host
${CC:-cc} -std=c11 -O1 -Wall -Wextra -Werror -fsanitize=undefined \
  -Isource source/game.c tests/test_game.c -lm -o build-host/test_game
./build-host/test_game
