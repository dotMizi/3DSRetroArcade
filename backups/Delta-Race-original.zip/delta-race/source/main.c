#include <3ds.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <sys/stat.h>
#include "game.h"
#define CYAN 0x58eaff
#define ORANGE 0xffa34f
static u8 *fb;
static void pixel(int x,int y,unsigned c) {if(x<0||x>=400||y<0||y>=240)return;int p=(x*240+239-y)*3;fb[p]=c&255;fb[p+1]=(c>>8)&255;fb[p+2]=(c>>16)&255;}
static void line(int x,int y,int xx,int yy,unsigned c) {int dx=abs(xx-x),sx=x<xx?1:-1,dy=-abs(yy-y),sy=y<yy?1:-1,e=dx+dy;for(;;){pixel(x,y,c);if(x==xx&&y==yy)break;int t=2*e;if(t>=dy){e+=dy;x+=sx;}if(t<=dx){e+=dx;y+=sy;}}}
static void box(int x,int y,int w,int h,unsigned c){line(x,y,x+w,y,c);line(x+w,y,x+w,y+h,c);line(x+w,y+h,x,y+h,c);line(x,y+h,x,y,c);}
static void circle(int x,int y,int r,unsigned c){for(int i=0;i<20;i++){float a=i*6.2831853f/20,b=(i+1)*6.2831853f/20;line(x+cosf(a)*r,y+sinf(a)*r,x+cosf(b)*r,y+sinf(b)*r,c);}}
static void ship(Game *g) {float a=g->angle;int x=g->ship.x,y=g->ship.y;float c=cosf(a),s=sinf(a);unsigned color=g->shield>0?0xffffff:CYAN;
 int nx=x+c*10,ny=y+s*10,lx=x-c*6-s*6,ly=y-s*6+c*6,rx=x-c*6+s*6,ry=y-s*6-c*6;
 line(nx,ny,lx,ly,color);line(lx,ly,x-c*3,y-s*3,color);line(x-c*3,y-s*3,rx,ry,color);line(rx,ry,nx,ny,color);
 if(g->thrust){line(lx,ly,x-c*17,y-s*17,ORANGE);line(rx,ry,x-c*17,y-s*17,ORANGE);}if(g->shield>0)circle(x,y,14,0x286b84);
}
static void render(Game *g) {
 fb=gfxGetFramebuffer(GFX_TOP,GFX_LEFT,NULL,NULL);memset(fb,0,400*240*3);
 for(int i=0;i<70;i++)pixel((i*137+23)%398,(i*i*17+31)%238,0x153047);
 box(10,10,380,220,0x327385);box(155,85,90,70,CYAN);box(159,89,82,62,0x163b56);
 // Original delta emblem at the centre of the arena.
 line(200,101,182,137,0x327385);line(182,137,218,137,0x327385);line(218,137,200,101,0x327385);
 for(int i=0;i<MAX_ENEMIES;i++){Enemy *e=&g->enemies[i];if(e->hp<=0)continue;unsigned c=e->type==1?0xff547b:ORANGE;
  int sides=e->type==2?6:4;float r=e->hp==2?9:7;for(int j=0;j<sides;j++){float a=e->turn+j*6.2831853f/sides,b=e->turn+(j+1)*6.2831853f/sides;line(e->b.x+cosf(a)*r,e->b.y+sinf(a)*r,e->b.x+cosf(b)*r,e->b.y+sinf(b)*r,c);}pixel(e->b.x,e->b.y,c);
 }
 for(int i=0;i<MAX_SHOTS;i++){Shot *s=&g->shots[i];if(s->life>0)line(s->b.x,s->b.y,s->b.x-s->b.vx*.018f,s->b.y-s->b.vy*.018f,s->hostile?0xff547b:0xcaffff);}
 for(int i=0;i<MAX_SPARKS;i++){Spark *s=&g->sparks[i];if(s->life>0)pixel(s->b.x,s->b.y,s->color);}
 if(g->playing)ship(g);
}
static const char *savePath="sdmc:/3ds/delta-race/highscore.txt";
static int loadBest(void){int n=0;FILE *f=fopen(savePath,"r");if(f){if(fscanf(f,"%d",&n)!=1 || n<0)n=0;fclose(f);}return n;}
static bool saveBest(int n){mkdir("sdmc:/3ds",0777);mkdir("sdmc:/3ds/delta-race",0777);FILE *f=fopen("sdmc:/3ds/delta-race/highscore.tmp","w");if(!f)return false;bool ok=fprintf(f,"%d\n",n)>0;if(fclose(f)!=0)ok=false;return ok && rename("sdmc:/3ds/delta-race/highscore.tmp",savePath)==0;}
int main(void){
 gfxInitDefault();consoleInit(GFX_BOTTOM,NULL);Game g;gameInit(&g,(uint32_t)osGetTime(),loadBest());int saved=g.best;bool saveFailed=false;u64 last=svcGetSystemTick();int frames=0;
 while(aptMainLoop()) {
  hidScanInput();u32 down=hidKeysDown(),held=hidKeysHeld();circlePosition cp;hidCircleRead(&cp);
  if(down&KEY_SELECT)break;
  if(!g.playing && (down&(KEY_A|KEY_START))){gameStart(&g);last=svcGetSystemTick();}
  else if(g.playing && (down&KEY_START)){g.paused=!g.paused;last=svcGetSystemTick();}
  u64 now=svcGetSystemTick();float dt=(now-last)/268123480.0;last=now;
  float turn=abs(cp.dx)>18?cp.dx/156.0f:0;if(held&KEY_LEFT)turn=-1;if(held&KEY_RIGHT)turn=1;
  touchPosition touch;hidTouchRead(&touch);bool touched=(held&KEY_TOUCH)&&touch.py>=140;
  Input in={turn,(held&(KEY_B|KEY_UP|KEY_L))||cp.dy>45||(touched&&touch.px<160),(held&(KEY_A|KEY_R))!=0||(touched&&touch.px>=160),(held&(KEY_X|KEY_DOWN))!=0};gameStep(&g,in,dt);
  if(!g.playing && g.best>saved){saveFailed=!saveBest(g.best);saved=g.best;}
  render(&g);
  if(frames++%6==0){printf("\x1b[H\x1b[36m        D E L T A   R A C E\x1b[0m\n\n");
   printf(" SCORE %08d    BEST %08d\n",g.score,g.best);printf(" LIVES %-2d  WAVE %-3d   ENEMIES %-2d\n\n",g.lives,g.wave,g.count);
   printf(" %-37s\n",!g.playing?(g.lives<=0?"GAME OVER - A / START: new game":"A / START: launch"):g.paused?"PAUSED - START: resume":!g.count?"Sector clear! Next wave incoming...":g.shield>0?"Spawn shield active":"Destroy all drones. Survive.");
   printf("\n Circle Pad / Left-Right: rotate\n B / L / Up:             thrust\n A / R:                  fire\n X / Down:               brake\n START:                  pause\n SELECT:                 exit\n\n");
   printf(" Touch y >= 140: left = thrust\n                right = fire\n\n Cyan: your ship   Pink: hunters\n Orange: drones / armoured sentries\n Walls bounce ships, stop shots.\n\n %-38s",saveFailed?"Highscore could not be saved.":"Original homebrew - no arcade assets.");
  }
  gfxFlushBuffers();gfxSwapBuffers();gspWaitForVBlank();
 }
 if(g.best>saved)saveBest(g.best);
 gfxExit();return 0;
}
